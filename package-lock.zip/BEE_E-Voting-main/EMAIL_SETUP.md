# Email Setup (Gmail)

This guide explains how to configure email for the E-Voting app so OTPs are delivered to real Gmail addresses.

## Option A — Gmail App Password (recommended)
1. Ensure your Google account has **2-Step Verification** enabled: https://myaccount.google.com/security
2. Create an **App Password** for Mail:
   - Sign in to Google → Security → App passwords → Select "Mail" → Generate
   - Copy the generated password (16 characters)
3. Update your `.env` file (use `.env.example` as a template):
```
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=465
EMAIL_SECURE=true
EMAIL_USER=your.email@gmail.com
EMAIL_PASS=your_generated_app_password
NODE_ENV=production
```
4. Restart your app and test with `node scripts/test-email.js` or register a user.

## Option B — Gmail OAuth2 (more secure)
1. Create a Google Cloud project and OAuth 2.0 Client Credentials (Desktop or Web type), then authorize and obtain a refresh token.
2. Set these in `.env`:
```
EMAIL_SERVICE=gmail
EMAIL_USER=your.email@gmail.com
EMAIL_OAUTH_CLIENT_ID=...
EMAIL_OAUTH_CLIENT_SECRET=...
EMAIL_OAUTH_REFRESH_TOKEN=...
NODE_ENV=production
```
3. Restart the app and test.

## Testing
- Run `node scripts/test-email.js` to verify delivery. If the app uses Ethereal test account (development), the script will print a preview URL instead of sending to Gmail.
- When using a real Gmail config and `NODE_ENV=production`, emails should be delivered to the recipient mailbox (check spam).

## Notes & Security
- Keep `.env` out of version control. Use `.env.example` as a template for developers.
- Do **not** store real credentials in the repository.
- Set `NODE_ENV=production` when using real SMTP to avoid dev fallback behavior and preview URLs.
