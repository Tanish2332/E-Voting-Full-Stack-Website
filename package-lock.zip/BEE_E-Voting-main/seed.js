require('dotenv').config();
const mongoose = require('mongoose');
const Admin = require('./models/admin.model');
const Voter = require('./models/voter.model');
const Candidate = require('./models/candidate.model');
const connectDB = require('./config/database');

const seedDatabase = async () => {
    try {
        await connectDB();
        console.log('Database connected for seeding...');

        await Admin.deleteMany({});
        await Voter.deleteMany({});
        await Candidate.deleteMany({});
        console.log('Cleared existing admin, voter, and candidate data.');

        const admin = new Admin({
            username: 'admin',
            password: 'adminpassword',
            email: process.env.ADMIN_EMAIL || 'teacher@example.com',
        });
        await admin.save();
        console.log(`Default admin user created (username: admin, password: adminpassword, email: ${admin.email}).`);

        const candidates = [
            { name: 'Aarav Sharma', party: 'National Unity Party' },
            { name: 'Priya Singh', party: 'Progressive Alliance' },
            { name: 'Rohan Gupta', party: 'People\'s Freedom Front' },
        ];
        await Candidate.insertMany(candidates);
        console.log('Sample candidates created.');

        console.log('Database seeding complete!');
    } catch (error) {
        console.error('Error seeding database:', error);
    } finally {
        mongoose.connection.close();
    }
};

seedDatabase();