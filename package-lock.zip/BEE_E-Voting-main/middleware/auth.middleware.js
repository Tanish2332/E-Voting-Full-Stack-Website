exports.isAuthenticated = (req, res, next) => {
    if (req.session && req.session.user) {
        return next();
    }
    req.flash('error_msg', 'Please log in to view this resource');
    res.redirect('/login');
};

exports.isAdmin = (req, res, next) => {
    if (req.session && req.session.user && req.session.user.role === 'admin') {
        return next();
    }
    req.flash('error_msg', 'Access denied. You must be an admin.');
    res.redirect('/');
};

exports.isVoter = (req, res, next) => {
    if (req.session && req.session.user && req.session.user.role === 'voter') {
        return next();
    }
    req.flash('error_msg', 'Access denied. You must be a voter.');
    res.redirect('/');
};

exports.redirectIfAuthenticated = (req, res, next) => {
    if (req.session && req.session.user) {
        if (req.session.user.role === 'admin') {
            return res.redirect('/admin/dashboard');
        } else {
            return res.redirect('/voter/dashboard');
        }
    }
    return next();
};