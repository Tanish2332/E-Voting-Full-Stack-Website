const mongoose = require('mongoose');

const candidateSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Candidate name is required'],
        trim: true
    },
    party: {
        type: String,
        required: [true, 'Party name is required'],
        trim: true
    },
    voteCount: {
        type: Number,
        default: 0
    }
}, { timestamps: true });

const Candidate = mongoose.model('Candidate', candidateSchema);
module.exports = Candidate;