const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const voterSchema = new mongoose.Schema({
    voterId: {
        type: String,
        required: [true, 'Voter ID is required'],
        unique: true,
        trim: true
    },
    email: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        lowercase: true
    },
    password: {
        type: String,
        required: [true, 'Password is required']
    },
    role: {
        type: String,
        default: 'voter'
    },
    hasVoted: {
        type: Boolean,
        default: false
    },
    isApproved: {
        type: Boolean,
        default: false
    }
    ,
    isEmailVerified: {
        type: Boolean,
        default: false
    },
    emailOtp: {
        type: String
    },
    otpExpiresAt: {
        type: Date
    }
}, { timestamps: true });

voterSchema.pre('save', async function (next) {
    if (!this.isModified('password')) return next();
    try {
        const salt = await bcrypt.genSalt(10);
        this.password = await bcrypt.hash(this.password, salt);
        return next();
    } catch (error) {
        return next(error);
    }
});

voterSchema.methods.comparePassword = async function (enteredPassword) {
    return await bcrypt.compare(enteredPassword, this.password);
};

const Voter = mongoose.model('Voter', voterSchema);
module.exports = Voter;