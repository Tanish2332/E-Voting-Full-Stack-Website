# E-Voting App

Simple e-voting system. See `EMAIL_SETUP.md` for email configuration details (Gmail App Password or OAuth2) to enable OTP delivery to real Gmail accounts.

Quick start:
1. Copy `.env.example` to `.env` and fill in values
2. `npm install`
3. `node seed.js` (if needed)
4. `npm start` or `node app.js`

For email setup and testing, see `EMAIL_SETUP.md`.
