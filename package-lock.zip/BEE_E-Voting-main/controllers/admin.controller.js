const Candidate = require('../models/candidate.model');
const Voter = require('../models/voter.model');
const sendNotificationEmail = require('../config/mailer');

// Renders the main dashboard
exports.getDashboard = async (req, res) => {
    try {
        const candidates = await Candidate.find({}).sort({ voteCount: -1 });
        const approvedVoters = await Voter.find({ isApproved: true }).sort({ createdAt: -1 });
        const pendingVoters = await Voter.find({ isApproved: false }).sort({ createdAt: -1 });
        const totalVotes = candidates.reduce((acc, candidate) => acc + candidate.voteCount, 0);

        res.render('pages/admin/dashboard', {
            title: 'Admin Dashboard',
            candidates,
            approvedVoters,
            pendingVoters,
            totalVotes
        });
    } catch (error) {
        console.error("Dashboard Error:", error);
        req.flash('error_msg', 'Could not load the dashboard.');
        res.redirect('/');
    }
};

// --- REGISTRATION MANAGEMENT FUNCTIONS ---

exports.approveVoter = async (req, res) => {
    try {
        const voter = await Voter.findByIdAndUpdate(req.params.id, { isApproved: true }, { new: true });
        
        if (voter) {
            req.flash('success_msg', 'Voter has been approved and notified.');
            const subject = 'Your E-Voting Registration has been Approved';
            const html = `<h2>Congratulations, ${voter.voterId}!</h2><p>Your registration for the E-Voting System has been approved. You can now log in and cast your vote.</p>`;
            await sendNotificationEmail(voter.email, subject, html);
        } else {
            req.flash('error_msg', 'Voter not found.');
        }

        res.redirect('/admin/dashboard');
    } catch (error) {
        req.flash('error_msg', 'Failed to approve voter.');
        res.redirect('/admin/dashboard');
    }
};

exports.rejectVoter = async (req, res) => {
    try {
        const voter = await Voter.findById(req.params.id);

        if (voter) {
            await Voter.findByIdAndDelete(req.params.id);
            req.flash('success_msg', 'Voter registration has been rejected and the user notified.');
            
            const subject = 'Update on Your E-Voting Registration';
            const html = `<h2>Hello, ${voter.voterId}</h2><p>We regret to inform you that your registration for the E-Voting System has been rejected.</p>`;
            await sendNotificationEmail(voter.email, subject, html);
        } else {
            req.flash('error_msg', 'Voter not found.');
        }

        res.redirect('/admin/dashboard');
    } catch (error) {
        req.flash('error_msg', 'Failed to reject voter.');
        res.redirect('/admin/dashboard');
    }
};

// --- VOTER MANAGEMENT FUNCTIONS ---

exports.addVoter = async (req, res) => {
    try {
        const { voterId, password } = req.body;
        if (!voterId || !password) {
            req.flash('error_msg', 'Voter ID and password are required.');
            return res.redirect('/admin/dashboard');
        }

        const existingVoter = await Voter.findOne({ voterId });
        if (existingVoter) {
            req.flash('error_msg', 'A voter with this ID already exists.');
            return res.redirect('/admin/dashboard');
        }

        const newVoter = new Voter({ voterId, password, isApproved: true });
        await newVoter.save();
        req.flash('success_msg', 'Voter added and approved successfully.');
        res.redirect('/admin/dashboard');

    } catch (error) {
        console.error(error);
        req.flash('error_msg', 'Failed to add voter.');
        res.redirect('/admin/dashboard');
    }
};

exports.deleteVoter = async (req, res) => {
    try {
        const voter = await Voter.findById(req.params.id);

        if (voter) {
            await Voter.findByIdAndDelete(req.params.id);
            req.flash('success_msg', 'Voter deleted and notified successfully.');
            
            const subject = 'Your E-Voting Account Has Been Removed';
            const html = `<h2>Hello, ${voter.voterId}</h2>
                        <p>This is a notification to inform you that your account for the E-Voting System has been removed by an administrator.</p>
                        <p>If you believe this is an error, please contact support immediately.</p>`;
            await sendNotificationEmail(voter.email, subject, html);
        } else {
            req.flash('error_msg', 'Voter not found.');
        }

        res.redirect('/admin/dashboard');
    } catch (error) {
        console.error(error);
        req.flash('error_msg', 'Failed to delete voter.');
        res.redirect('/admin/dashboard');
    }
};

// --- CANDIDATE MANAGEMENT FUNCTIONS ---

exports.addCandidate = async (req, res) => {
    try {
        const { name, party } = req.body;
        if (!name || !party) {
            req.flash('error_msg', 'Please fill in all fields.');
            return res.redirect('/admin/dashboard');
        }
        const newCandidate = new Candidate({ name, party });
        await newCandidate.save();
        req.flash('success_msg', 'Candidate added successfully.');
        res.redirect('/admin/dashboard');
    } catch (error) {
        console.error(error);
        req.flash('error_msg', 'Failed to add candidate.');
        res.redirect('/admin/dashboard');
    }
};

exports.updateCandidate = async (req, res) => {
    try {
        const { id } = req.params;
        const { name, party } = req.body;
        await Candidate.findByIdAndUpdate(id, { name, party });
        req.flash('success_msg', 'Candidate updated successfully.');
        res.redirect('/admin/dashboard');
    } catch (error) {
        console.error(error);
        req.flash('error_msg', 'Failed to update candidate.');
        res.redirect('/admin/dashboard');
    }
};

exports.deleteCandidate = async (req, res) => {
    try {
        await Candidate.findByIdAndDelete(req.params.id);
        req.flash('success_msg', 'Candidate deleted successfully.');
        res.redirect('/admin/dashboard');
    } catch (error) {
        console.error(error);
        req.flash('error_msg', 'Failed to delete candidate.');
        res.redirect('/admin/dashboard');
    }
};