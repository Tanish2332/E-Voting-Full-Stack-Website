const Candidate = require('../models/candidate.model');
const Voter = require('../models/voter.model');

exports.getDashboard = async (req, res) => {
    try {
        const voter = await Voter.findById(req.session.user.id);

        if (voter.hasVoted) {
            return res.render('pages/voter/voted', { title: 'Thank You' });
        }

        const candidates = await Candidate.find({});
        res.render('pages/voter/dashboard', {
            title: 'Voter Dashboard',
            candidates: candidates
        });
    } catch (error) {
        console.error(error);
        req.flash('error_msg', 'Could not fetch dashboard data.');
        res.redirect('/');
    }
};

exports.castVote = async (req, res) => {
    try {
        const voterId = req.session.user.id;
        const candidateId = req.params.id;

        const voter = await Voter.findById(voterId);

        if (voter.hasVoted) {
            req.flash('error_msg', 'You have already cast your vote.');
            return res.redirect('/voter/dashboard');
        }

        await Candidate.findByIdAndUpdate(candidateId, { $inc: { voteCount: 1 } });
        await Voter.findByIdAndUpdate(voterId, { hasVoted: true });

        req.flash('success_msg', 'Your vote has been successfully cast!');
        res.redirect('/voter/dashboard');

    } catch (error) {
        console.error(error);
        req.flash('error_msg', 'An error occurred while casting your vote.');
        res.redirect('/voter/dashboard');
    }
};