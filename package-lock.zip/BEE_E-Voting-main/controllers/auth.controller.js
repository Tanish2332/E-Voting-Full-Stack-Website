const Admin = require('../models/admin.model');
const Voter = require('../models/voter.model');
const sendNotificationEmail = require('../config/mailer');

// Helper to generate a 6-digit OTP
function generateOtp() {
    return Math.floor(100000 + Math.random() * 900000).toString();
}

// --- RENDER REGISTER and LOGIN PAGES ---
exports.renderRegisterPage = (req, res) => {
    res.render('pages/register', { title: 'Register' });
};
exports.renderLoginPage = (req, res) => {
    res.render('pages/login', { title: 'Login' });
};

// --- HANDLE REGISTRATION ---
exports.handleRegister = async (req, res) => {
    try {
        const { voterId, email, password, confirmPassword } = req.body;

        if (password !== confirmPassword) {
            req.flash('error_msg', 'Passwords do not match.');
            return res.redirect('/register');
        }

        const existingVoter = await Voter.findOne({ $or: [{ voterId }, { email }] });
        if (existingVoter) {
            req.flash('error_msg', 'A voter with this ID or email already exists.');
            return res.redirect('/register');
        }
        
        // Create voter but mark email as not verified yet
        const newVoter = new Voter({ voterId, email, password, isEmailVerified: false });

        // generate OTP
        const otp = generateOtp();
        newVoter.emailOtp = otp;
        newVoter.otpExpiresAt = Date.now() + 10 * 60 * 1000; // 10 minutes
        await newVoter.save();

        // send OTP email
        const subject = 'Your E-Voting email verification code';
        const html = `<p>Your verification code is <strong>${otp}</strong>. It expires in 10 minutes.</p>`;
        const mailResult = await sendNotificationEmail(email, subject, html);
        if (process.env.NODE_ENV !== 'production') {
            console.log(`DEBUG: Sent registration OTP to ${email}`);
            if (mailResult && mailResult.previewUrl) req.flash('success_msg', `An OTP has been sent to your email. Preview: ${mailResult.previewUrl}`);
        }

        // store pending verification in session and redirect to verify page
        req.session.pendingVerification = { userId: newVoter._id, next: '/login' };
        req.flash('success_msg', 'An OTP has been sent to your email. Please verify to complete registration.');
        // ensure session is saved before redirect so verification state persists
        return req.session.save(err => {
            if (err) console.error('Session save error (register):', err);
            return res.redirect('/verify-email');
        });
    } catch (error) {
        console.error("Registration Error:", error);
        req.flash('error_msg', 'Something went wrong. Please try again.');
        res.redirect('/register');
    }
};

// --- HANDLE LOGIN (with approval check) ---
exports.handleLogin = async (req, res) => {
    try {
        const { userType, identifier, password } = req.body;
        let user = null;

        if (userType === 'admin') {
            user = await Admin.findOne({ username: identifier });
        } else {
            user = await Voter.findOne({ $or: [{ voterId: identifier }, { email: identifier }] });
        }

        if (!user || !(await user.comparePassword(password))) {
            req.flash('error_msg', 'Invalid credentials.');
            return res.redirect('/login');
        }

        // Only voters require approval
        if (user.role === 'voter' && !user.isApproved) {
            req.flash('error_msg', 'Your account is pending approval by an administrator.');
            return res.redirect('/login');
        }

        // For voters, send OTP for email verification as a second step
        // Optionally require OTP for admin logins when configured
        const requireAdminOtp = process.env.REQUIRE_ADMIN_OTP === 'true';
        if (user.role === 'voter' || (user.role === 'admin' && requireAdminOtp)) {
            const otp = generateOtp();
            user.emailOtp = otp;
            user.otpExpiresAt = Date.now() + 10 * 60 * 1000; // 10 minutes
            await user.save();

            const subject = 'Your E-Voting login verification code';
            const html = `<p>Your login verification code is <strong>${otp}</strong>. It expires in 10 minutes.</p>`;

            if (user.email) {
                const mailResult = await sendNotificationEmail(user.email, subject, html);
                if (process.env.NODE_ENV !== 'production') {
                    console.log(`DEBUG: Sent login OTP to ${user.email}`);
                    if (mailResult && mailResult.previewUrl) req.flash('success_msg', `An OTP has been sent to your email. Preview: ${mailResult.previewUrl}`);
                }
            } else {
                // If admin has no email and we're not in production, log notice for debugging (do not reveal OTP)
                if (process.env.NODE_ENV !== 'production') {
                    console.warn('No email for user; OTP generated for debugging (not displayed for security).');
                    console.log(`DEBUG: Login OTP generated for ${user.username || user.voterId}`);
                } else {
                    req.flash('error_msg', 'No email configured for this account. Contact support.');
                    return res.redirect('/login');
                }
            }

            // store pending login in session (include role so verify can lookup correct model)
            req.session.pendingLogin = { userId: user._id, role: user.role };
            req.flash('success_msg', 'An OTP has been sent to your email. Please enter it to complete login.');
            // ensure session is saved before redirect so verification state persists
            return req.session.save(err => {
                if (err) console.error('Session save error (login):', err);
                return res.redirect('/verify-email');
            });
        }

        // Admin login (no OTP) - create session
        req.session.user = {
            id: user._id,
            identifier: user.username || user.voterId,
            role: user.role,
        };

        if (user.role === 'admin') {
            return res.redirect('/admin/dashboard');
        } else {
            return res.redirect('/voter/dashboard');
        }
    } catch (error) {
        console.error("Login Error:", error);
        req.flash('error_msg', 'An error occurred during login.');
        res.redirect('/login');
    }
};

// --- RENDER VERIFY PAGE ---
exports.renderVerifyPage = (req, res) => {
    // determine if we have a pending action
    const pendingVerification = req.session.pendingVerification;
    const pendingLogin = req.session.pendingLogin;
    if (!pendingVerification && !pendingLogin) {
        req.flash('error_msg', 'No verification in progress.');
        return res.redirect('/login');
    }
    res.render('pages/verify-email', { title: 'Verify Email' });
};

// --- HANDLE OTP SUBMISSION ---
exports.handleVerify = async (req, res) => {
    try {
        const { otp } = req.body;
        const pendingVerification = req.session.pendingVerification;
        const pendingLogin = req.session.pendingLogin;

        let user = null;
        let type = null;
        if (pendingVerification) {
            user = await Voter.findById(pendingVerification.userId);
            type = 'register';
        } else if (pendingLogin) {
            // pendingLogin includes role; choose model accordingly
            if (pendingLogin.role === 'admin') {
                user = await Admin.findById(pendingLogin.userId);
            } else {
                user = await Voter.findById(pendingLogin.userId);
            }
            type = 'login';
        }

        if (!user) {
            req.flash('error_msg', 'Verification session expired or invalid.');
            return res.redirect('/login');
        }

        if (!user.emailOtp || !user.otpExpiresAt || Date.now() > user.otpExpiresAt) {
            req.flash('error_msg', 'OTP expired. Please request a new one.');
            return res.redirect('/verify-email');
        }

        if (user.emailOtp !== otp) {
            req.flash('error_msg', 'Invalid OTP.');
            return res.redirect('/verify-email');
        }

        // valid OTP
        // Mark email verified on voters; admins may not have this flag
        if (user.isEmailVerified === undefined) {
            // do nothing; admin schema doesn't include isEmailVerified by default
        } else {
            user.isEmailVerified = true;
        }
        user.emailOtp = undefined;
        user.otpExpiresAt = undefined;
        await user.save();

        // Clear pending sessions
        if (pendingVerification) delete req.session.pendingVerification;
        if (pendingLogin) delete req.session.pendingLogin;

        if (type === 'register') {
            req.flash('success_msg', 'Email verified! Please wait for admin approval before logging in.');
            return res.redirect('/login');
        }

        if (type === 'login') {
            // create session user and redirect based on role
            req.session.user = {
                id: user._id,
                identifier: user.username || user.voterId,
                role: user.role,
            };
            if (user.role === 'admin') return res.redirect('/admin/dashboard');
            return res.redirect('/voter/dashboard');
        }
    } catch (error) {
        console.error('Verification Error:', error);
        req.flash('error_msg', 'An error occurred during verification.');
        res.redirect('/verify-email');
    }
};

// --- RESEND OTP ---
exports.resendOtp = async (req, res) => {
    try {
        const pendingVerification = req.session.pendingVerification;
        const pendingLogin = req.session.pendingLogin;
        let user = null;
        if (pendingVerification) user = await Voter.findById(pendingVerification.userId);
        else if (pendingLogin) {
            if (pendingLogin.role === 'admin') user = await Admin.findById(pendingLogin.userId);
            else user = await Voter.findById(pendingLogin.userId);
        }

        if (!user) {
            req.flash('error_msg', 'No verification in progress.');
            return res.redirect('/login');
        }

        const otp = generateOtp();
        user.emailOtp = otp;
        user.otpExpiresAt = Date.now() + 10 * 60 * 1000;
        await user.save();

        const subject = 'Your E-Voting verification code (resend)';
        const html = `<p>Your verification code is <strong>${otp}</strong>. It expires in 10 minutes.</p>`;
        if (user.email) {
            const mailResult = await sendNotificationEmail(user.email, subject, html);
            if (process.env.NODE_ENV !== 'production') {
                console.log(`DEBUG: Resent OTP to ${user.email}`);
                if (mailResult && mailResult.previewUrl) req.flash('success_msg', `A new OTP has been sent to your email. Preview: ${mailResult.previewUrl}`);
            }
        } else {
            if (process.env.NODE_ENV !== 'production') {
                console.warn('No email for user; logging resend OTP for debug.');
                console.log(`DEBUG: Resend OTP for ${user.username || user.voterId} is ${otp}`);
                req.flash('success_msg', `A new OTP has been generated: ${otp}`);
            } else {
                req.flash('error_msg', 'No email configured for this account. Contact support.');
                return res.redirect('/verify-email');
            }
        }

        req.flash('success_msg', 'A new OTP has been sent to your email.');
        return req.session.save(err => {
            if (err) console.error('Session save error (resend):', err);
            return res.redirect('/verify-email');
        });
    } catch (error) {
        console.error('Resend OTP Error:', error);
        req.flash('error_msg', 'Unable to resend OTP.');
        res.redirect('/verify-email');
    }
};

// --- HANDLE LOGOUT ---
exports.handleLogout = (req, res) => {
    req.session.destroy(err => {
        if (err) {
            console.error('Session destruction error:', err);
            return res.redirect('/');
        }
        res.clearCookie('connect.sid');
        res.redirect('/login');
    });
};