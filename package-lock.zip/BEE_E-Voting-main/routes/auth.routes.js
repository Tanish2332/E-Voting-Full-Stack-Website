const express = require('express');
const router = express.Router();
const authController = require('../controllers/auth.controller');
const { redirectIfAuthenticated } = require('../middleware/auth.middleware');

router.get('/login', redirectIfAuthenticated, authController.renderLoginPage);
router.post('/login', authController.handleLogin);

router.get('/register', redirectIfAuthenticated, authController.renderRegisterPage);
router.post('/register', authController.handleRegister);
router.get('/verify-email', authController.renderVerifyPage);
router.post('/verify-email', authController.handleVerify);
router.post('/verify-email/resend', authController.resendOtp);

router.get('/logout', authController.handleLogout);

module.exports = router;