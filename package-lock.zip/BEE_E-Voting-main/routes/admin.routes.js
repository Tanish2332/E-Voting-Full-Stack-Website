const express = require('express');
const router = express.Router();
const adminController = require('../controllers/admin.controller');
const { isAuthenticated, isAdmin } = require('../middleware/auth.middleware');

router.use(isAuthenticated, isAdmin);

router.get('/dashboard', adminController.getDashboard);

router.post('/candidates/add', adminController.addCandidate);
router.post('/candidates/update/:id', adminController.updateCandidate);
router.post('/candidates/delete/:id', adminController.deleteCandidate);

router.post('/voters/add', adminController.addVoter);
router.post('/voters/delete/:id', adminController.deleteVoter);

router.post('/voters/approve/:id', adminController.approveVoter);
router.post('/voters/reject/:id', adminController.rejectVoter);

module.exports = router;