const express = require('express');
const router = express.Router();
const voterController = require('../controllers/voter.controller');
const { isAuthenticated, isVoter } = require('../middleware/auth.middleware');

router.use(isAuthenticated, isVoter);

router.get('/dashboard', voterController.getDashboard);
router.post('/vote/:id', voterController.castVote);

module.exports = router;