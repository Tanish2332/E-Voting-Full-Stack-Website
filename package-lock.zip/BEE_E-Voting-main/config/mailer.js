const nodemailer = require('nodemailer');
const { google } = require('googleapis');

// Configure the email transporter using environment variables.
// If EMAIL_HOST is not provided, create a test Ethereal account for development.
let transporter;
/**
 * createTransporter()
 * Supports three modes (priority order):
 * 1) Gmail OAuth2 (set EMAIL_SERVICE=gmail and OAuth env vars)
 * 2) SMTP with basic auth (set EMAIL_HOST, EMAIL_USER, EMAIL_PASS)
 * 3) Ethereal test account (development fallback)
 *
 * For Gmail OAuth2 you need to set these env vars:
 * - EMAIL_SERVICE=gmail
 * - EMAIL_USER=<your gmail address>
 * - EMAIL_OAUTH_CLIENT_ID
 * - EMAIL_OAUTH_CLIENT_SECRET
 * - EMAIL_OAUTH_REFRESH_TOKEN
 *
 * Alternatively, you can use an App Password for Gmail with basic SMTP:
 * - Set EMAIL_HOST=smtp.gmail.com, EMAIL_PORT=465, EMAIL_SECURE=true,
 *   EMAIL_USER=<your gmail address>, EMAIL_PASS=<app password>
 */
async function createTransporter() {
    // Gmail OAuth2
    if (process.env.EMAIL_SERVICE === 'gmail' && process.env.EMAIL_OAUTH_CLIENT_ID && process.env.EMAIL_OAUTH_CLIENT_SECRET && process.env.EMAIL_OAUTH_REFRESH_TOKEN && process.env.EMAIL_USER) {
        const oAuth2Client = new google.auth.OAuth2(process.env.EMAIL_OAUTH_CLIENT_ID, process.env.EMAIL_OAUTH_CLIENT_SECRET);
        oAuth2Client.setCredentials({ refresh_token: process.env.EMAIL_OAUTH_REFRESH_TOKEN });
        const accessTokenObj = await oAuth2Client.getAccessToken();
        const accessToken = accessTokenObj && accessTokenObj.token ? accessTokenObj.token : null;

        return nodemailer.createTransport({
            service: 'gmail',
            auth: {
                type: 'OAuth2',
                user: process.env.EMAIL_USER,
                clientId: process.env.EMAIL_OAUTH_CLIENT_ID,
                clientSecret: process.env.EMAIL_OAUTH_CLIENT_SECRET,
                refreshToken: process.env.EMAIL_OAUTH_REFRESH_TOKEN,
                accessToken: accessToken,
            },
        });
    }

    // Basic SMTP using provided host/creds (supports Gmail App Passwords)
    if (process.env.EMAIL_HOST && process.env.EMAIL_USER && process.env.EMAIL_PASS) {
        return nodemailer.createTransport({
            host: process.env.EMAIL_HOST,
            port: process.env.EMAIL_PORT ? Number(process.env.EMAIL_PORT) : 587,
            secure: process.env.EMAIL_SECURE === 'true' || false,
            auth: {
                user: process.env.EMAIL_USER,
                pass: process.env.EMAIL_PASS,
            },
        });
    }

    // Create test account for development
    const testAccount = await nodemailer.createTestAccount();
    return nodemailer.createTransport({
        host: 'smtp.ethereal.email',
        port: 587,
        secure: false,
        auth: {
            user: testAccount.user,
            pass: testAccount.pass,
        },
    });
}

// Initialize transporter asynchronously but keep reference
createTransporter().then(t => { transporter = t; }).catch(err => { console.error('Failed to create mail transporter', err); });

/**
 * Sends a notification email.
 * @param {string} to - The recipient's email address.
 * @param {string} subject - The subject line of the email.
 * @param {string} html - The HTML body of the email.
 */
const sendNotificationEmail = async (to, subject, html) => {
    try {
        if (!transporter) transporter = await createTransporter();
        const info = await transporter.sendMail({
            from: `"E-Voting System" <no-reply@evoting.com>`,
            to: to,
            subject: subject,
            html: html,
        });

        const previewUrl = nodemailer.getTestMessageUrl(info) || null;
        console.log("Message sent: %s", info.messageId);
        if (previewUrl) console.log("Preview URL: %s", previewUrl);
        return { info, previewUrl };
    } catch (error) {
        console.error("Error sending email:", error);

        // In development, attempt to fall back to an Ethereal test account so developers
        // still receive a preview URL instead of failing outright (useful for local dev
        // when .env contains placeholder SMTP entries like smtp.example.com).
        if (process.env.NODE_ENV !== 'production') {
            try {
                console.warn('Falling back to Ethereal test account for development...');
                const testAccount = await nodemailer.createTestAccount();
                const fallbackTransporter = nodemailer.createTransport({
                    host: 'smtp.ethereal.email',
                    port: 587,
                    secure: false,
                    auth: {
                        user: testAccount.user,
                        pass: testAccount.pass,
                    },
                });

                const info2 = await fallbackTransporter.sendMail({
                    from: `"E-Voting System" <no-reply@evoting.com>`,
                    to: to,
                    subject: subject,
                    html: html,
                });

                const previewUrl2 = nodemailer.getTestMessageUrl(info2) || null;
                console.log("Fallback message sent: %s", info2.messageId);
                if (previewUrl2) console.log("Preview URL: %s", previewUrl2);
                return { info: info2, previewUrl: previewUrl2 };
            } catch (fallbackErr) {
                console.error('Fallback (Ethereal) send failed:', fallbackErr);
            }
        }

        throw error;
    }
};

module.exports = sendNotificationEmail;