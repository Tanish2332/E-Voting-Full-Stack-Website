require('dotenv').config();
const sendNotificationEmail = require('../config/mailer');

(async () => {
    try {
        const to = process.env.TEST_EMAIL_TO || process.env.EMAIL_USER;
        if (!to) {
            console.error('TEST_EMAIL_TO or EMAIL_USER must be set in .env');
            process.exit(1);
        }
        const subject = 'E-Voting Test Email';
        const html = `<p>This is a test email from your E-Voting app. If you received it, mail is configured correctly.</p>`;
        const result = await sendNotificationEmail(to, subject, html);
        console.log('Send result:', result && result.info ? result.info.messageId : 'no-info');
        if (result && result.previewUrl) console.log('Preview URL:', result.previewUrl);
        process.exit(0);
    } catch (err) {
        console.error('Error sending test email:', err);
        process.exit(2);
    }
})();
