const fetch = require('node-fetch');

(async () => {
    const res = await fetch('http://localhost:3002/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ voterId: 'testvoter1', email: 'testvoter1@example.com', password: 'Password123!', confirmPassword: 'Password123!' })
    });
    console.log('Status:', res.status);
    const text = await res.text();
    console.log('Body snippet:', text.slice(0, 300));
})();